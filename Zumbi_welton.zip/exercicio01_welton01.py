# encoding:utf8
#
# Curso: Python para Zumbies - exercício 1
#
# Faça um programa que peça dois números inteiros e imprima a soma desses dois números
#
import os
os.system("clear") # Limpando a tela

numero1 = int(input("Digite o primeiro número: "))
numero2 = int(input("Digite o Segundo número : "))
print ("A soma dos dois numeros é : ", numero1 + numero2)
